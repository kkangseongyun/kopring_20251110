package org.example.test2

var data1: String = "kim"
var data2: String? = "kim"

fun main() {
    //non-null type 에는 절대 null 대입 불가능.. NPE 고려대상이 되지 못한다..
//    data1 = null //error...
    data2 = null//ok

    var data3: String? = data1//non-null ==> nullable, 정상.. 암시적 캐스팅..
//    var data4: String = data2//error... nullable --> non-null , 명시적 캐스팅..

    data2 = "kim" //ok
    //null 값이 대입되어 있는 상황에서 as 로 캐스팅을 하면 런타임 에러가 발생한다..
    //as? null이면 캐스팅을 하지 마라.. 전체 결과는 null
    data2 = null
    var data4: String = data2 as? String ?: ""

    data2?.length

    println("hello")
}