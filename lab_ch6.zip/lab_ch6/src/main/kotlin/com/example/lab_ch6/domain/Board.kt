package com.example.lab_ch6.domain

import jakarta.persistence.Entity
import jakarta.persistence.GeneratedValue
import jakarta.persistence.Id
import java.util.Date

@Entity
data class Board (

    @Id
    @GeneratedValue
    var seq: Int = 0,
    var title: String,

    var writer: String,
    var content: String,

    var createDate: Date = Date(),
    var cnt: Int = 0
)