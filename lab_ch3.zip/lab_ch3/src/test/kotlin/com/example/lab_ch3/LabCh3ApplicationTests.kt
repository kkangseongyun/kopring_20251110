package com.example.lab_ch3

import com.example.lab_ch3.domain.BoardVO
import com.example.lab_ch3.service.BoardService
import com.ninjasquad.springmockk.MockkBean
import io.mockk.every
import org.junit.jupiter.api.Test
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.boot.test.context.SpringBootTest
import org.springframework.boot.test.web.client.TestRestTemplate
import org.springframework.boot.test.web.client.getForObject
import kotlin.test.assertEquals


//E2E 테스트를 진행하고자 한다..
// ==> 톰캣 서버가 구동되어야 한다..
// ==> 가상의 브라우저 mock 객체가 있어야 한다..
//BoardService 의 빈은 테스트 도중에 실행되면 안된다..
// ==>가상의 mock 으로 대체해야 한다..
@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
class LabCh3ApplicationTests {

    //브라우저..
    @Autowired
    lateinit var restTemplate: TestRestTemplate

    @MockkBean
    lateinit var boardService: BoardService

	@Test
	fun contextLoads() {
        //가상의 결과 데이터..
        val board = BoardVO(seq = 1, title = "테스트", writer = "홍길동", content = "내용")

        //mock 객체에게 어떻게 움직여야 하는지 명시..
        //boardService.getBoard(1) 로 호출이 된다면 board 를 리턴하라..
        every { boardService.getBoard(1) } returns board

        val result = restTemplate.getForObject<BoardVO>("/getBoard?seq=1")
        assertEquals("홍길동", result?.writer)
	}

}
