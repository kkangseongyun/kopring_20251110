package com.example.lab_ch3.service

import com.example.lab_ch3.domain.BoardVO
import com.example.lab_ch3.repository.BoardRepository
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.stereotype.Service

@Service
class BoardService {
    @Autowired
    lateinit var boardRepository: BoardRepository

    init {
        println("==> BoardService 생성")
    }
    fun hello(name: String): String {
        return "Hello : $name"
    }

    fun getBoard(seq: Int): BoardVO{
        return boardRepository.getBoard(seq)
    }
    fun getBoardList(): List<BoardVO> {
        return boardRepository.getBoardList()
    }
}