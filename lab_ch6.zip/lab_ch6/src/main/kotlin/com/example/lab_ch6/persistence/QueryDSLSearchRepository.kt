package com.example.lab_ch6.persistence

import com.example.lab_ch6.domain.Board
import com.example.lab_ch6.domain.QBoard
import com.querydsl.jpa.impl.JPAQueryFactory
import jakarta.persistence.EntityManager
import org.springframework.data.repository.query.Param
import org.springframework.stereotype.Repository

@Repository
class QueryDSLSearchRepository(
    val entityManager: EntityManager
) {
    val queryFactory by lazy { JPAQueryFactory(entityManager) }
    val board = QBoard.board

    fun findBoardByWriter(keyword: String): List<Board> {
        return queryFactory
            .selectFrom(board)
            .where(board.writer.eq(keyword))
            .fetch()//이 순간 실행.
    }

    fun findByTitleContainingOrderBySeqDesc(keyword: String): List<Board>{
        return queryFactory
            .selectFrom(board)
            .where(board.title.contains(keyword))
            .orderBy(board.seq.desc())
            .fetch()
    }

    fun findByContentContaining(keyword: String): List<Board>{
        return queryFactory
            .selectFrom(board)
            .where(board.content.contains(keyword))
            .fetch()
    }

    fun findByTitleContainingOrContentContaining(
        title: String,
        content: String): List<Board>{
        return queryFactory
            .selectFrom(board)
            .where(board.title.contains(title).or(board.content.contains(content)))
            .fetch()
    }
}