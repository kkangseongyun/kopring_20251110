package com.example.lab_ch6.persistence

import com.example.lab_ch6.domain.Board
import org.springframework.data.jpa.repository.JpaRepository

//개발자가 원한다면.. 함수를 더 추가할 수도 있지만..(QueryMethod)... JpaRepository 를 상속 받는 것만으로..
//dbms 를 위한 기초 함수가 추가된다..
//save(), saveAll(), findById()....
interface JPABoardRepository: JpaRepository<Board, Int>