package com.example.lab_ch3.repository

import com.example.lab_ch3.domain.BoardVO
import org.springframework.stereotype.Repository

@Repository
class BoardRepository {
    init {
        println("==> BoardRepository 생성")
    }

    fun getBoard(seq: Int): BoardVO {
        println("==>BoardRepository getBoard()")
        val board = BoardVO(
            seq = 1, title = "테스트 제목", writer = "테스터", content = "테스트 내용"
        )
        return board
    }
    fun getBoardList(): List<BoardVO> {
        println("==>BoardRepository getBoardList()")
        val board1 = BoardVO(
            seq = 1, title = "테스트 제목1", writer = "테스터1", content = "테스트 내용1"
        )
        val board2 = BoardVO(
            seq = 2, title = "테스트 제목2", writer = "테스터2", content = "테스트 내용2"
        )
        return listOf(board1, board2)
    }
}