package com.example.lab_ch5.domain

import java.util.Date

data class Board(
    var seq: Int = 0,
    var title: String,
    var writer: String,
    var content: String,
    var createDate: Date = Date(),
    var cnt: Int = 0
)