package com.example.lab_ch6.persistence

import com.example.lab_ch6.domain.Board
import org.apache.ibatis.javassist.compiler.ast.Keyword
import org.springframework.data.jpa.repository.JpaRepository
import org.springframework.data.jpa.repository.Query
import org.springframework.data.repository.query.Param

interface JPQLSearchRepository: JpaRepository<Board, Int>{
    //JPQL 이 등록된 곳의 함수명은 임의 이름..
    @Query("SELECT b FROM Board b WHERE b.writer = :keyword")
    fun findBoardByWriter(@Param("keyword") keyword: String): List<Board>

    @Query("SELECT b FROM Board b WHERE b.title LIKE %:keyword% ORDER BY b.seq DESC")
    fun findByTitleContainingOrderBySeqDesc(@Param("keyword") keyword: String): List<Board>

    @Query("SELECT b FROM Board b WHERE b.content LIKE %:keyword%")
    fun findByContentContaining(@Param("keyword") keyword: String): List<Board>

    @Query("SELECT b FROM Board b WHERE b.title LIKE %:title% OR b.content LIKE %:content%")
    fun findByTitleContainingOrContentContaining(
        @Param("title") title: String,
        @Param("content") content: String): List<Board>
}