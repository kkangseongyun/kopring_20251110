package com.example.lab_ch3.controller

import com.example.lab_ch3.domain.User
import com.example.lab_ch3.service.UserService
import org.springframework.web.bind.annotation.GetMapping
import org.springframework.web.bind.annotation.RestController

@RestController
class UserController(
    val userService: UserService
) {
    @GetMapping("/users")
    fun getAllUser(): List<User> {
        return userService.getAllUser()
    }
}