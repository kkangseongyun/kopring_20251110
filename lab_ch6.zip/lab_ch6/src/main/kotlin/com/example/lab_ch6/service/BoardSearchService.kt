package com.example.lab_ch6.service

import com.example.lab_ch6.domain.Board
import com.example.lab_ch6.persistence.JPABoardRepository
import com.example.lab_ch6.persistence.JPQLSearchRepository
import com.example.lab_ch6.persistence.QueryDSLSearchRepository
import com.example.lab_ch6.persistence.QueryMethodSearchRepository
import org.springframework.stereotype.Service

@Service
class BoardSearchService(
//    private val searchRepository: JPQLSearchRepository
//    private val searchRepository: QueryMethodSearchRepository
    private val searchRepository: QueryDSLSearchRepository
) {
    fun search(searchType: String, keyword: String): List<Board>{
        return when(searchType){
            "title" -> searchRepository.findByTitleContainingOrderBySeqDesc(keyword)
            "writer" -> searchRepository.findBoardByWriter(keyword)
            "content" -> searchRepository.findByContentContaining(keyword)
            "titleContent" ->searchRepository.findByTitleContainingOrContentContaining(keyword, keyword)
            else -> listOf()
        }
    }
}