package com.example.lab_ch4.validator

import jakarta.validation.Constraint
import jakarta.validation.Payload
import kotlin.reflect.KClass

//데이터가 저장되는 필드에 명시할 제약조건.. 어노테이션 선언되어야...
@Target(AnnotationTarget.FIELD, AnnotationTarget.PROPERTY)
@Retention(AnnotationRetention.RUNTIME)
@MustBeDocumented
//validator를 위해 추가해야 하는 정보..
@Constraint(validatedBy = [MinStringLengthValidator::class])
annotation class MyMinStringLength(
    //어노테이션을 추가한 곳에서 부가적으로 받아들이고 싶은 데이터..
    val value: Int,
    //validator를 만든다면.. 아래는 필수..
    val message: String = "문자열 길이가 {value}자 이상이어야 합니다.",//invalid 상황에서의 기본 메시지
    val groups: Array<KClass<*>> = [],//여러 validator를 그룹핑 하기 위한 설정..
    val payload: Array<KClass<out Payload>> = []// 검증 실패시 부가 정보..
)