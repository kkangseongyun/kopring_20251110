package com.example.lab_ch7.service

import com.example.lab_ch7.domain.User
import com.example.lab_ch7.persistence.UserRepository
import org.springframework.security.crypto.password.PasswordEncoder
import org.springframework.stereotype.Service


@Service
class UserService(
    private val userRepository: UserRepository,
    private val passwordEncoder: PasswordEncoder
) {
    fun registerUser(user: User): Boolean {
        return if (userRepository.existsById(user.id)) {
            false
        } else {
            user.password = passwordEncoder.encode(user.password)
            user.role = "USER"
            userRepository.save(user)
            true
        }
    }
}