package org.example.test3

fun main() {
    //배열 변수 선언.. 선언과 동시에 값 대입이 가능한 경우..
    val array = arrayOf(1, "hello",  true)
    //배열 타입을 표현할 때는 [] 표현식이 없지만.. 데이터 index 접근할 때는 [1]로...
    array[0] = 10
    println("${array[0]}, ${array.get(0)}")

    //기초 타입의 배열을 위한 api 가 따로 선언되어 있다..
    arrayOf<Int>(10, 20)
    intArrayOf(10, 20)//사용이 가능하지만.. 자바 호환성 문제로 별도 기초타입 배열 선언 api를 제공하는 것이다..

    //사이즈, 초기값 선언..
    //{ 0 } 람다함수로.. 이 함수의 리턴 값이 초기값..
    val array2 = Array(3, { 0 })
    val array3 = Array(3, {i -> i * 10})

    //기초타입 배열 클래스가 따로 준비..
    val array4 = IntArray(3, { 0 })


    //mutable, immutable... List, Set, Map
    val list1: List<String> = listOf("hello", "world")
    val list2: MutableList<String> = mutableListOf("hello", "world")
    println("${list1.get(0)}, ${list2.get(0)}")
//    list1.add("aaa")//error
//    list1.set(1, "bbb")//error
    list2.add("aaa")//error
    list2.set(1, "bbb")//error

    //if expression................
    val a = 5
    if(a > 10) "hello"//ok...
    //expression 으로 활용이 된다면.. else 생략 불가.. false 일 경우 대입되는 값 명시가 필요해서..
    val result = if(a > 10) "hello" else "world"

    val result1 = if(a > 10){
        println("hello")
        10 + 20//마지막 실행 라인의 결과값이 대입..
    }else {
        30 + 40
    }
}