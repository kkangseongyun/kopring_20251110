package com.example.lab_ch3

import org.junit.jupiter.api.Test
import org.springframework.boot.test.context.SpringBootTest

@SpringBootTest
class LabCh3ApplicationTests {

	@Test
	fun contextLoads() {
	}

}
