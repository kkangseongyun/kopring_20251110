package com.example.lab_ch6.persistence

import com.example.lab_ch6.domain.Board
import org.springframework.data.jpa.repository.JpaRepository
import org.springframework.data.jpa.repository.Query
import org.springframework.data.repository.query.Param

interface QueryMethodSearchRepository: JpaRepository<Board, Int> {
    fun findBoardByWriter(@Param("keyword") keyword: String): List<Board>

    fun findByTitleContainingOrderBySeqDesc(@Param("keyword") keyword: String): List<Board>

    fun findByContentContaining(@Param("keyword") keyword: String): List<Board>

    fun findByTitleContainingOrContentContaining(
        @Param("title") title: String,
        @Param("content") content: String): List<Board>
}