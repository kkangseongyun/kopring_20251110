package org.example.test4

//주생자에 한해서.. 멤버변수에 val, var을 추가해서.. 멤버변수로 선언가능..
//주생성자가 다른 예약어와 같이 사용되지 않는다면.. constructor 생략 가능..
class User1 constructor(val name: String, val age: Int){
    init {
        //객체 생성 시점에 실행되는 부분...
        //주로 주 생성자로 객체 생성될때 실행되는 코드를 담기 위해서..
        //보조 생성자로 객체 생성해도 실행된다..
        //init -> constructor
        println("init.... $name, $age")
    }

    fun sayHello(){
        println("hello $name, $age")
    }
}

class User2(name: String) {
    //주 생성자가 선언되어 있다면..보조 생성자에서는 주 생성자 호출해야 한다..
    constructor(name: String, age: Int): this(name){
//        this(name)//생성자 바디에 다른 생성자 호출구문 작성 불가..
        println("constructor...$name, $age")
    }
}

class User3(name: String) {
    constructor(name: String, age: Int): this(name)
    //보조 생성자가 여러개 있다면.. 다른 보조생성자를 호출할 수는 있지만.. 무조건.. 생성자 연결관계로 주생성자는 호출되어야
    constructor(name: String, age: Int, email: String): this(name, age)
}