package com.example.lab_ch7

import org.springframework.boot.autoconfigure.SpringBootApplication
import org.springframework.boot.runApplication

@SpringBootApplication
class LabCh7Application

fun main(args: Array<String>) {
	runApplication<LabCh7Application>(*args)
}
