package org.example.starter

import okhttp3.OkHttpClient
import org.slf4j.Logger
import org.slf4j.LoggerFactory
import org.springframework.boot.autoconfigure.AutoConfiguration
import org.springframework.boot.autoconfigure.condition.ConditionalOnClass
import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty
import org.springframework.boot.context.properties.EnableConfigurationProperties
import org.springframework.context.annotation.Bean

//자동 설정 기능을 제공하기 위한 클래스이다.. 설정이 이미 적용된 bean 을 ioc container에 등록하기 위한 클래스..
//AutoConfiguration.imports 에 등록되어야 한다..
//org.springframework.boot.autoconfigure.AutoConfiguration.imports
@AutoConfiguration
@ConditionalOnClass(OkHttpClient::class)
//starter를 이용하는 애플리케이션 개발자가 아래의 property 설정을 한 경우에..
@ConditionalOnProperty(
    prefix = "myteam.okhttp",
    name = ["enabled"],
    havingValue = "true",
    matchIfMissing = true//기본 값..
)
//application.yml 의 설정 값이.. OkHttpProperties 에 등록되게..
@EnableConfigurationProperties(OkHttpProperties::class)
class OkHttpAutoConfiguration {
    private val logger = LoggerFactory.getLogger(OkHttpAutoConfiguration::class.java)

    //함수를 호출하고.. 함수의 리턴 객체를 ioc container 에 빈으로 등록..
    @Bean
    @ConditionalOnMissingBean//이 빈이 등록이 안되어 있다면..
    fun okHttpClientCustomizer(properties: OkHttpProperties): OkHttpClientCustomizer {
        logger.info("okHttpClientCustomizer...................")
        return OkHttpClientCustomizer(properties)
    }

    @Bean
    @ConditionalOnMissingBean
    fun okHttpClient(customizer: OkHttpClientCustomizer): OkHttpClient {
        logger.info("okHttpClient............")
        return customizer.customize()
    }

}