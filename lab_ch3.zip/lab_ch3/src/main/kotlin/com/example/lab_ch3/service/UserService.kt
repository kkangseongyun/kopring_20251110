package com.example.lab_ch3.service

import com.example.lab_ch3.domain.User
import com.example.lab_ch3.repository.UserRepository
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.stereotype.Service

@Service
class UserService {
    @Autowired
    lateinit var userRepository: UserRepository

    fun getAllUser(): List<User>{
        return userRepository.getAllUser()
    }
}