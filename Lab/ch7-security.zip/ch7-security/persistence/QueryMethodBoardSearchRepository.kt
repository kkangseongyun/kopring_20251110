package com.example.lab_ch7.persistence

import com.example.lab_ch7.domain.Board
import org.springframework.data.jpa.repository.JpaRepository

interface QueryMethodBoardSearchRepository: JpaRepository<Board, Int> {

    //작성자 검색
    fun findBoardByWriter(keyword: String): List<Board>

    fun findByTitleContainingOrderBySeqDesc(keyword: String): List<Board>

    fun findByContentContaining(keyword: String): List<Board>

    fun findByTitleContainingOrContentContaining(title: String, content: String): List<Board>

}