package com.example.lab_ch6.service

import com.example.lab_ch6.domain.Board
import com.example.lab_ch6.persistence.BoardMapper
import org.springframework.stereotype.Service

@Service
class MyBatisBoardService(
    private val boardMapper: BoardMapper
) {
    fun getBoard(seq: Int): Board {
        return boardMapper.getBoard(seq)
    }
    fun getBoardList(): List<Board> {
        return boardMapper.getBoardList()
    }
    fun insertBoard(board: Board){
        boardMapper.insertBoard(board)
    }
    fun updateBoard(seq: Int, board: Board){
        boardMapper.updateBoard(seq, board)
    }
    fun deleteBoard(seq: Int){
        boardMapper.deleteBoard(seq)
    }
}