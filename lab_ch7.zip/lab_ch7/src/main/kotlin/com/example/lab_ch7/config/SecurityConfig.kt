package com.example.lab_ch7.config

import org.springframework.context.annotation.Bean
import org.springframework.context.annotation.Configuration
import org.springframework.security.config.annotation.web.builders.HttpSecurity
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder
import org.springframework.security.crypto.password.PasswordEncoder
import org.springframework.security.web.SecurityFilterChain

//spring security 를 위한 설정...
@Configuration
@EnableWebSecurity
class SecurityConfig {
    @Bean
    fun passwordEncoder(): PasswordEncoder = BCryptPasswordEncoder()

    //이 함수에서 리턴시키는 객체에 설정대로 움직인다..
    @Bean
    fun filterChain(http: HttpSecurity): SecurityFilterChain {
        return http
            .csrf { it.disable() }//비활성화..
            .authorizeHttpRequests { //인가 설정...
                it.requestMatchers("/", "/getBoard", "/register","/login").permitAll()
                it.requestMatchers("/deleteBoard/**").hasRole("ADMIN")
                it.anyRequest().authenticated()//인증만 되면.. 허락..
            }
            .formLogin {
                //로그인 화면을 띄워야 한다면 이 url 을 get 으로 이용하라..
                it.loginPage("/login")
                //post 방식으로 이 url 요청이 로그인 처리 요청이다..
                it.loginProcessingUrl("/login")
                it.defaultSuccessUrl("/")//로그인 성공시 띄울 url
                it.failureUrl("/login?error=true")//로그인 실패시..
                it.usernameParameter("id")//로그인 요청 정보중 이 키로..
                it.passwordParameter("password")
            }
            .logout {
                it.logoutUrl("/logout")//이 url 로 로그아웃 요청 들어온다..
                it.logoutSuccessUrl("/")
            }
            .build()
    }
}