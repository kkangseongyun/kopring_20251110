package com.example.lab_ch3.property

import org.springframework.boot.context.properties.ConfigurationProperties

//application.yml 설정한 내용을 가지는 클래스.. 객체가 생성되어 ioc container에 관리되게 만들고 싶다..
//필요한 곳에서 DI로 주입받아 사용하게 하고자 한다..
//@ConfigurationProperties 에 의해.. application.yml 이 이 클래스 객체의 멤버에 대입되지만..
//@ConfigurationProperties 만으로.. 이 객체가 생성되어.. spring ioc container 에 등록되지는 않는다.
@ConfigurationProperties(prefix = "app")
data class AppProperties(
    val name: String = "",
    val version: String = "",
    val author: Author = Author(),
    val feature: Feature = Feature()
){
    data class Author(
        val name: String = "",
        val email: String = ""
    )
    data class Feature(
        val enabled: Boolean = false,
        val maxUsers: Int = 0
    )
}