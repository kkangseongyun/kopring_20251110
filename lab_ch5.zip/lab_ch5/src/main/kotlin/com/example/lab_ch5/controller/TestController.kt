package com.example.lab_ch5.controller

import org.springframework.beans.factory.annotation.Autowired
import org.springframework.cglib.core.Local
import org.springframework.context.MessageSource
import org.springframework.http.HttpStatus
import org.springframework.stereotype.Controller
import org.springframework.ui.Model
import org.springframework.web.bind.annotation.GetMapping
import org.springframework.web.server.ResponseStatusException
import java.util.Locale

@Controller
class TestController {
    @GetMapping("/test1")
    fun test1(): String {
        throw ResponseStatusException(HttpStatus.NOT_FOUND, "페이지가 없습니다.")
    }

    @GetMapping("/test2")
    fun test2(): String {
        throw RuntimeException("서버 에러 발생")
    }

    @Autowired
    lateinit var messageSource: MessageSource

    @GetMapping("/test3")
    fun test3(locale: Locale, model: Model): String {
        //메시지 획득..
        val message = messageSource.getMessage("welcome.message", null, locale)
        model.addAttribute("message", message)
        //화면에 출력될 뷰 이름..
        return "thymeleaf/message"
    }
}