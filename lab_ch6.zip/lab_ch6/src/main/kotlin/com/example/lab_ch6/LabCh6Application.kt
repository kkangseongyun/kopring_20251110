package com.example.lab_ch6

import org.springframework.boot.autoconfigure.SpringBootApplication
import org.springframework.boot.runApplication

@SpringBootApplication
class LabCh6Application

fun main(args: Array<String>) {
	runApplication<LabCh6Application>(*args)
}
