package com.example.lab_ch3.repository

import com.example.lab_ch3.domain.User
import org.springframework.stereotype.Repository

@Repository
class UserRepository {
    fun getAllUser(): List<User>{
        val users = listOf<User>(
            User("1", "kim", "a@a.com"),
            User("2", "lee", "b@b.com")
        )
        return users
    }
}
//java -jar .\lab_ch3-0.0.1-SNAPSHOT.jar