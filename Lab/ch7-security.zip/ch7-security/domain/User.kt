package com.example.lab_ch7.domain

import jakarta.persistence.Entity
import jakarta.persistence.Id
import jakarta.persistence.Table

@Entity
@Table(name = "TB_USERS")
data class User(
    @Id
    var id: String = "",
    var password: String = "",
    var name: String = "",
    var role: String = ""
)