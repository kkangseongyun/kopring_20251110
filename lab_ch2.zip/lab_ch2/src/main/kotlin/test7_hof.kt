package org.example.test7

fun main() {
    //hof 함수 선언......
    fun myFilter(list: List<Int>, argFun: (Int) -> Boolean): List<Int>{
        val resultList = mutableListOf<Int>()

        val iterator = list.iterator()
        while (iterator.hasNext()){
            val no = iterator.next()
            val result = argFun(no)
            if(result){
                resultList.add(no)
            }
        }
        return resultList
    }
    val testList = listOf<Int>(10, 13, 3, 6, 20)
    val resultList = myFilter(testList, {x -> x > 10})
    myFilter(testList){x -> x > 5}
    myFilter(testList){ it > 5 }


    class User(var name: String, var age: Int){
        fun sayHello(){}
    }
    val user = User("kim", 10)
    user.name = "lee"
    user.age = 30
    user.sayHello()

    user.run {
        name = "park"
        age = 40
        sayHello()
    }

    user.let {
        it.name = "hello"
        it.age = 2
    }
}