package org.example.test6

class User1(val no: Int, val name: String)

//data 클래스는 자동으로 equals, toString 함수가 추가되는데.. 주생성자의 멤버변수만 보고 작성된다..
data class User2(val no: Int, val name: String){
    //data 클래스 얼마든지.. 클래스 바디 가질 수 있다..
    var email: String? = null
    //보조 생성자 가능하다..
    constructor(no: Int, name: String, email: String): this(no, name){
        this.email = email
    }
}

interface MyInterface {
    fun myFun()
}
open class Super {
    fun superFun(){

    }
}

class Outer {
    val obj1: MyInterface = object : Super(), MyInterface {
        override fun myFun() {

        }
    }

    //AA 생략도 가능하다..
    companion object AA {
        val no = 10
        fun myFun(){}
    }
}

fun main() {
    val user1 = User1(1, "kim")
    val user2 = User1(1, "kim")
    val user3 = User2(1, "kim", "a@a.com")
    val user4 = User2(1, "kim", "b@a.com")

    //data 클래스의 equals 는 값 비교인데.. 주생성자의 멤버만...
    println("${user1.equals(user2)}, ${user3.equals(user4)}")//false, true

    //객체 비교를 원한다면..
    //자바에는 === 이 없다.. == => equals() 로, === => == 로...
    println("${user3 == user4}, ${user3 === user4}")//true, false

    //toString()
    println(user1.toString())//org.example.test6.User1@41629346
    println(user3.toString())//User2(no=1, name=kim)

    Outer.AA.no
    Outer.AA.myFun()

    Outer.no
    Outer.myFun()
}