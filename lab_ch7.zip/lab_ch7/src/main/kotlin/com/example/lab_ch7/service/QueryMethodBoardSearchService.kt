package com.example.lab_ch7.service


import com.example.lab_ch7.domain.Board
import com.example.lab_ch7.persistence.QueryMethodBoardSearchRepository
import org.springframework.stereotype.Service

@Service
class QueryMethodBoardSearchService(
    private val searchRepository: QueryMethodBoardSearchRepository
) {

    fun search(searchType: String, keyword: String): List<Board>{
        return  when(searchType){
            "title" -> searchRepository.findByTitleContainingOrderBySeqDesc(keyword)
            "writer" -> searchRepository.findBoardByWriter(keyword)
            "content" -> searchRepository.findByContentContaining(keyword)
            "titleContent" -> searchRepository.findByTitleContainingOrContentContaining(keyword, keyword)
            else -> listOf()
        }
    }
}