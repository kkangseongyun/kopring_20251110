package com.example.lab_ch4.domain

import com.example.lab_ch4.validator.MyMinStringLength
import jakarta.validation.constraints.NotBlank

data class UserDto(
    @field:NotBlank
    val name: String?,
    @field:MyMinStringLength(value = 6)
    val password: String?
)