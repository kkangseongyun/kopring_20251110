package org.example.starter

import org.springframework.boot.context.properties.ConfigurationProperties
import java.time.Duration

@ConfigurationProperties(prefix = "myteam.okhttp")
data class OkHttpProperties(
    var enabled: Boolean = true,

    
    var connectTimeout: Duration = Duration.ofSeconds(10),

    
    var readTimeout: Duration = Duration.ofSeconds(30),

   
    var writeTimeout: Duration = Duration.ofSeconds(30),

    
    var logging: LoggingProperties = LoggingProperties()
){

    class LoggingProperties {
       
        var enabled: Boolean = false

       
        var level: String = "BASIC"
    }
}