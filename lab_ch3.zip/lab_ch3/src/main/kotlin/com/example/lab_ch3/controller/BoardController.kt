package com.example.lab_ch3.controller

import com.example.lab_ch3.domain.BoardVO
import com.example.lab_ch3.service.BoardService
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.web.bind.annotation.GetMapping
import org.springframework.web.bind.annotation.RestController

@RestController
class BoardController {
    init {
        println("==> BoardController")
    }

    @Autowired
    lateinit var boardService: BoardService

    @GetMapping("/getBoard")
    fun getBoard(seq: Int): BoardVO {
        //BoardService... Controller에서 요청을 받으면 실행시키는 로직을 가지는 빈..
        //테스트 화면에서는 실제 실행시키면 안되는 빈..
        return boardService.getBoard(seq)
    }
}