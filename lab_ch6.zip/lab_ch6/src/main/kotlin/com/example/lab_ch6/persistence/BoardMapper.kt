package com.example.lab_ch6.persistence

import com.example.lab_ch6.domain.Board
import org.apache.ibatis.annotations.Mapper

@Mapper
interface BoardMapper {
    //xml 각 태그의 id 와 동일 이름의 함수만 선언..
    fun insertBoard(board: Board)
    fun updateBoard(seq: Int, board: Board)
    fun deleteBoard(seq: Int)
    fun getBoardList(): List<Board>
    fun getBoard(seq: Int): Board
}