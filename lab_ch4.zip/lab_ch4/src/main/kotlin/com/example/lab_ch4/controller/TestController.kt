package com.example.lab_ch4.controller

import org.springframework.http.HttpStatus
import org.springframework.http.ResponseEntity
import org.springframework.web.bind.annotation.GetMapping
import org.springframework.web.bind.annotation.ModelAttribute
import org.springframework.web.bind.annotation.PathVariable
import org.springframework.web.bind.annotation.PostMapping
import org.springframework.web.bind.annotation.RequestBody
import org.springframework.web.bind.annotation.RequestMapping
import org.springframework.web.bind.annotation.RequestParam
import org.springframework.web.bind.annotation.ResponseStatus
import org.springframework.web.bind.annotation.RestController

@RestController
@RequestMapping("/api")
class TestController {

    //여러 request data 를 담기 위한 dto
    data class ParamDto(val data1: Int, val data2: String, val data3: Boolean)

    @GetMapping("/test1/{pathValue1}/{pathValue2}")
    fun test1(
        @PathVariable pathValue1: Int,
        @PathVariable("pathValue2") pathV2: String,//변수명과 path 정보가 다르다면 명시적으로
        @RequestParam paramData1: Int,
        @RequestParam("paramData2") param2: String,
        @ModelAttribute paramDto: ParamDto
    ): String {
        return """
            pathValue1 : $pathValue1,
            pathValue2 : $pathV2,
            paramData1 : $paramData1,
            paramData2 : $param2,
            dto : $paramDto
        """.trimIndent()
    }

    @PostMapping("/test2")
    //body stream 으로 넘어오는 jsonb 데이터를 파싱해서.. 매개변수 타입의 dto 객체 생성, 담아준다..
    //만약 json 이 넘어왔는데.. 받는 곳의 타입이 String 이면 json 문자열 그대로 전달된다..
    fun test2(@RequestBody body: ParamDto): String {
        return body.toString()
    }

    data class User(val id: String, val name: String, val email: String)

    //annotation 으로 response status 지정..
    @GetMapping("/test3")
    @ResponseStatus(HttpStatus.CREATED)
    fun test3(): User {
        return User("1", "kim", "kim@a.com")
    }

    //세밀한 response 설정이 필요한 경우..
    @GetMapping("/test4")
    fun test4(): ResponseEntity<User> {
        return ResponseEntity.status(HttpStatus.CREATED)
            .header("X-Total-Count", "100")
            .body(User("1", "kim", "kim@a.com"))
    }

}
















