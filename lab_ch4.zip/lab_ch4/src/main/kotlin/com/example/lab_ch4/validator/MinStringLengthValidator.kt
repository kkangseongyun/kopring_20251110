package com.example.lab_ch4.validator

import jakarta.validation.ConstraintValidator
import jakarta.validation.ConstraintValidatorContext

//Validator 가 추가된 데이터의 검증 알고리즘 제공.. 성공/실패 판단..
class MinStringLengthValidator: ConstraintValidator<MyMinStringLength, String?> {
    private var minLength: Int = 0

    //필수 오버라이드 대상은 아니다..
    //어노테이션에 추가된 정보를 활용해야 하는 경우, 그 정보를 획득하기 위해서..
    override fun initialize(constraintAnnotation: MyMinStringLength) {
        this.minLength = constraintAnnotation.value
    }
    //검증을 위해 자동 호출.. 이 함수에서 리턴결과에 의해 valid/invalid
    //첫번째 매개변수가 어노테이션이 추가된 변수에 대입된 값..
    override fun isValid(p0: String?, p1: ConstraintValidatorContext?): Boolean {
        if(p0 == null)
            return true
        return p0.length >= minLength
    }
}