package com.example.lab_ch5.controller

import com.example.lab_ch5.domain.Board
import org.springframework.stereotype.Controller
import org.springframework.ui.Model
import org.springframework.web.bind.annotation.GetMapping
import org.springframework.web.bind.annotation.PathVariable
import org.springframework.web.bind.annotation.PostMapping
import org.springframework.web.bind.annotation.RequestMapping
import org.springframework.web.bind.annotation.RequestParam

@Controller
@RequestMapping("/thymeleaf")
class BoardController {
    //가상의 데이터..
    val boardList = mutableListOf<Board>()
    var seq = 0

    init {
        boardList.add(Board(++seq, "title1", "writer1", "content1"))
        boardList.add(Board(++seq, "title2", "writer2", "content2"))
    }

    //list 하면 요청은 get 방식이지만.. 다른 post 방식의 요청이 들어왔을 때 업무 처리 후에 forward 시켜서
    //바로 목록화면이 나오게 처리할 생각..
    //post 방식에도 동작해야 해서..
    @RequestMapping("/getBoardList")
    fun getBoardList(model: Model): String {
        model.addAttribute("boardList", boardList)
        return "thymeleaf/getBoardList"
    }

    //글 입력 화면 요청..
    @GetMapping("/insertBoard")
    fun insertBoardView(): String {
        return "thymeleaf/insertBoard"
    }
    //글 입력 처리 요청..
    @PostMapping("/insertBoard")
    fun insertBoard(board: Board): String {
        board.seq = ++seq
        boardList.add(board)
        return "forward:getBoardList"
    }

    //글 조회..
    @GetMapping("/getBoard")
    fun getBoard(@RequestParam seq: Int, model: Model): String {
        model.addAttribute("board", boardList.find { it.seq == seq })
        return "thymeleaf/getBoard"
    }

    //글 수정 화면 요청...
    //그 화면에 이전 글 내용이 찍혀야 한다..
    @GetMapping("/updateBoard/{seq}")
    fun updateBoardView(@PathVariable seq: Int, model: Model): String {
        model.addAttribute("board", boardList.find { it.seq == seq })
        //insert 와 update 를 동일 html 이용, 모드로 구분만 시키고자 한다..
        model.addAttribute("mode", "update")
        return "thymeleaf/insertBoard"
    }
    //update 데이터 처리 요청..
    @PostMapping("/updateBoard/{seq}")
    fun updateBoard(@PathVariable seq: Int, board: Board): String {
        val index = boardList.indexOfFirst { it.seq == seq }
        boardList[index] = board
        return "redirect:/thymeleaf/getBoardList"
    }

    @PostMapping("/deleteBoard/{seq}")
    fun deleteBoard(@PathVariable seq: Int): String {
        boardList.removeIf { it.seq == seq }
        return "redirect:/thymeleaf/getBoardList"
    }
}