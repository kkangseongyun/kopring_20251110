package com.example.lab_ch7.service

import com.example.lab_ch7.persistence.UserRepository
import org.springframework.security.core.userdetails.User
import org.springframework.security.core.userdetails.UserDetails
import org.springframework.security.core.userdetails.UserDetailsService
import org.springframework.security.core.userdetails.UsernameNotFoundException
import org.springframework.stereotype.Service

//Security 에 의해 실행될 서비스.. 로그인 요청시.. 사용자 정보를 로딩하기 위해서 이용..
@Service
class CustomUserDetailsService(
    private val userRepository: UserRepository
): UserDetailsService {
    //로그인 요청시 자동 호출된다.. 매개변수가 id 이다..
    override fun loadUserByUsername(username: String): UserDetails? {
        val user = userRepository.findById(username)
            .orElseThrow { UsernameNotFoundException("user not found") }

        //security context에 유지할 사용자 정보를 리턴시킨다..
        //리턴 된 값으로.. 알아서 로그인 성공/실패를 판단다며.. 이후 요청시에 인가를 판단하게 된다..
        return User.builder()
            .username(user.id)
            .password(user.password)
            .authorities("ROLE_${user.role}")
            .build()
    }
}