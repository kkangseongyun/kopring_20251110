package org.example.test5

class User {
    //property.. accessor 내장...
    var name: String = "kim"
        get() = field.uppercase()
        set(value){
            field = "Hello" +value
        }
    val age: Int = 20
        get() = field
}

//custom accessor를 추가했는데.. 코드에서 field 예약어를 사용하지 않았다면..
//자바로 변경될 시점에.. 변수가 선언되지 않는다.. 함수만 만들어진다..
//초기값을 줄 수 없다. get() 에서만 초기화 할 수 있다..
//val data1: String = "hello"
//    get() = "kim"

class User2 {
    lateinit var data1: String
//    lateinit val data2: String//error..
//    lateinit var data3: Int //error
//    lateinit var data4: String?//error..

    //by lazy 부분이 실행되어 초기화 되는데 실행 시점(초기화 시점)을 실제 이 변수가 최초로 이용되는 순간으로
    //미루고 싶을때..
    val name: String by lazy {
        println("by lazy......")
        "hello"
    }
}

fun main() {
    val user = User()
    user.name = "lee"
    println("name : ${user.name}, age : ${user.age}")

    val user2 = User2()
    println("before....")
    println(user2.name)
    println("after...")
    //before....
    //by lazy......
    //hello
    //after...
}