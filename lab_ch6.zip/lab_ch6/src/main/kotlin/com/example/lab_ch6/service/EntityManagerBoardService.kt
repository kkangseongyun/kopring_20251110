package com.example.lab_ch6.service

import com.example.lab_ch6.domain.Board
import jakarta.persistence.EntityManager
import jakarta.transaction.Transactional
import org.springframework.stereotype.Service

@Service
@Transactional//서비스의 선언된 함수 단위 트랜젝션 처리가 된다. 함수내에서 다시 선언해서 클래스레벨의 속성 변경 가능하고
class EntityManagerBoardService(
    val entityManager: EntityManager
) {
    fun getBoard(seq: Int): Board {
        return entityManager.find(Board::class.java, seq)
            ?: throw RuntimeException("board not found")
    }
    fun getBoardList(): List<Board>{
        //EntityManager에는 동일 타입의 데이터 여러건을 획득하기 위한 함수가 없다..
        //JPQL
        return entityManager.createQuery("SELECT b FROM Board b", Board::class.java)
            .resultList
    }
    fun insertBoard(board: Board){
        //엔티티 저장.. jpa context 에 등록..
        entityManager.persist(board)
    }
    fun updateBoard(seq: Int, board: Board){
        val existBoard = entityManager.find(Board::class.java, seq)
            ?: throw RuntimeException("not found")
        existBoard.title = board.title
        existBoard.writer = board.writer
        existBoard.content = board.content
        existBoard.cnt = board.cnt

        //exitBoard 객체가 이미 jpa context 에 관리 상태임으로 값만 변경하면 update
    }
    fun deleteBoard(seq: Int){
        val existBoard = entityManager.find(Board::class.java, seq)
            ?: throw RuntimeException("not found")
        entityManager.remove(existBoard)
    }
}