package org.example

import kotlin.random.Random
import kotlin.random.nextInt

//코틀린 언어는 default 초기화 지원하지 않는다..
//선언과 동시에 초기값을 대입하거나.. 초기화 시점을 미루는 방법을 명시해야 한다..
//모든것이 객체이고.. null safety 를 지원하기 때문에.. default 초기화를 지원하지 않는다.
val data1: Int = 10
var data2: Int = 20

class MyClass {
    val data3: Int = 30
    var data4: Int = 40

    fun myFun(){
        //local variable 에 한해서는 선언과 동시에 초기값을 주지 않아도 된다.. default 초기화는 지원안된다..
        //선언 이후에 따로 초기화 가능하기는 하지만.. 이용하기 전에는 초기화 되어 있어야 한다..
        val data5: Int
        var data6: Int

        data5 = 10
        data6 = 20

        val result = data5 + data6
    }
}

//val - 초기값을 대입한 후에.. 값 변경이 안된다..
//값 변경은 불가능하지만.. 그렇다고 상수 변수는 아니다..
//코틀린의 변수는 field(값만 가지는 변수)가 아니라.. property(내장 accessor를 가지는)다..
//변수를 이용한다는 것은 내장된 accessor(getter/setter)를 이용하는 것이다..
//개발자에 의해 custom accessor 가 추가될 수 있고.. 그런 이유로 상수변수가 아니다..
val myData: Int
    get() {
        return Random.nextInt(0, 100)
    }


//상수 변수 선언은 const 예약어로..
const val myConst = 10//var 로 선언은 불가능하다..

class A {
//    const val myConst2 = 10//error... 클래스 멤버 변수를 상수 변수로 만들 수 없다..
    //top level 에 변수가 선언될 수 있어서..

    object B {//object 로 선언되는 클래스.. 익명 클래스.. 어자피.. 하나만 생성 가능..
        const val myConst3 = 10//object 클래스내에는 상수 변수 선언 가능..
    }
}
fun main() {
    MyClass().myFun()

//    myData = 20//error...

    println(myData)
    println(myData)

    //모든 것이 객체이다.. 기초타입 객체의 자동 캐스팅 안된다..
    val data1 = 10
    val data2: Double = data1.toDouble()
    val data3: Int = data2.toInt()
}