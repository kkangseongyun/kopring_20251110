package com.example.lab_ch7.persistence

import com.example.lab_ch7.domain.Board
import org.springframework.data.jpa.repository.JpaRepository

interface JPABoardRepository: JpaRepository<Board, Int>
