package com.example.lab_ch3.controller

import com.example.lab_ch3.domain.User
import com.example.lab_ch3.property.AppProperties
import com.example.lab_ch3.service.UserService
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.beans.factory.annotation.Value
import org.springframework.core.env.Environment
import org.springframework.web.bind.annotation.GetMapping
import org.springframework.web.bind.annotation.RestController

@RestController
class UserController(
    val userService: UserService
) {
    @GetMapping("/users")
    fun getAllUser(): List<User> {
        return userService.getAllUser()
    }

    //custom property 를 개별적으로 활용할때...
    @Value("\${app.name}")
    lateinit var appName: String

    @Value("\${app.feature.enabled:false}")//기본 값 설정 가능하다..
    var featureEnabled: Boolean = false

    @Autowired
    lateinit var appProperties: AppProperties

    //프로그래밍적으로.. properties 값을 획득하고자 할때.. 개별 설정값 이용할 때..
    @Autowired
    lateinit var env: Environment

    @GetMapping("/property")
    fun test1(): String {
        println("""
            @Value - 
            $appName
            $featureEnabled
        """.trimIndent())

        println("""
            @ConfigurationProperties - 
            ${appProperties.name}
            ${appProperties.author.name} - ${appProperties.author.email}
        """.trimIndent())

        //Environment 로 획득하면서.. 타입 지정 가능.. 기본값 명시 가능..
        println("""
            Environment - 
            ${env.getProperty("app.name")}
            ${env.getProperty("app.feature.maxUsers", Int::class.java, 100)}
        """.trimIndent())

        return "test ok"
    }
}