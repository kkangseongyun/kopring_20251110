package com.example.lab_ch6.service

import com.example.lab_ch6.domain.Board
import com.example.lab_ch6.persistence.JPABoardRepository
import org.springframework.stereotype.Service

@Service
class JPABoardService(
    private val boardRepository: JPABoardRepository
) {
    fun getBoard(seq: Int): Board {
        return boardRepository.findById(seq)
            .orElseThrow {
                RuntimeException("board not found : $seq")
            }
    }

    fun getBoardList(): List<Board>{
        return boardRepository.findAll()
    }

    fun insertBoard(board: Board){
        boardRepository.save(board)
    }

    fun updateBoard(seq: Int, board: Board){
        //실제 데이터베이스에 저장된 데이터를 가지는 엔티티 객체를 수정...
        val existingBoard = boardRepository.findById(seq)
            .orElseThrow { RuntimeException("board not found") }
        existingBoard.title = board.title
        existingBoard.writer = board.writer
        existingBoard.content = board.content
        existingBoard.cnt = board.cnt

        boardRepository.save(existingBoard)
    }

    fun deleteBoard(seq: Int){
        boardRepository.deleteById(seq)
    }
}