package com.example.lab_ch3

import org.springframework.boot.autoconfigure.SpringBootApplication
import org.springframework.boot.context.properties.ConfigurationPropertiesScan
import org.springframework.boot.runApplication

@SpringBootApplication
//클래스 패스내에 모든 @ConfigurationProperties 어노테이션이 붙은 클래스 찾아서.. 생성,, ico container에 등록
@ConfigurationPropertiesScan
class LabCh3Application

fun main(args: Array<String>) {
	runApplication<LabCh3Application>(*args)
}
